#!/usr/bin/env python3

from .. import cli


	cli.welcome_user()


if __name__ == '__main__':
    main()
