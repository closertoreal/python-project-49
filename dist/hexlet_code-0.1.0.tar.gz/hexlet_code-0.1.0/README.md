### Hexlet tests and linter status:
[![Actions Status](https://github.com/closertoreal/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/closertoreal/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/a6cc2edafa0b4c95cb10/maintainability)](https://codeclimate.com/github/closertoreal/python-project-49/maintainability)

[my asciinema cast](https://asciinema.org/a/OS6uT7xbTTRs4ak5CLlbK8HdV)

[asciinema 6th step](https://asciinema.org/a/COVhkJGTRdCC3jSSIsHAf4chg)
