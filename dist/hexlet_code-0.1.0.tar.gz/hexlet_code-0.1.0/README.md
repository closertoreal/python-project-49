### Hexlet tests and linter status:
[![Actions Status](https://github.com/closertoreal/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/closertoreal/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/a6cc2edafa0b4c95cb10/maintainability)](https://codeclimate.com/github/closertoreal/python-project-49/maintainability)

[asciinema 5th step](https://asciinema.org/a/OS6uT7xbTTRs4ak5CLlbK8HdV)

[asciinema 6th step](https://asciinema.org/a/dE7Ek4YyxutpnMmd8wOhFAGGP)

[asciinema 7th step](https://asciinema.org/a/8UinL7sEUbIhdKugrX9UADxhI)

[asciinema 8th step](https://asciinema.org/a/LBgH7SnnJpLx2kheuVuuf4gM0)

[asciinema 9th step](https://asciinema.org/a/4EnO2ICaAaOndmfyLUTQUSoi0)
